package org.bgspa.ecommercebg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommercebgApplicationTests {

	@Test
	void contextLoads() {
	}

}
