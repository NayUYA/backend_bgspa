package org.bgspa.ecommercebg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommercebgApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcommercebgApplication.class, args);
	}

}
